// ============================================================
// FILE: components/Footer.js
// Navy blue footer with links, contacts, and India flag accent
// ============================================================

import { Shield, Phone, Globe, Mail } from "lucide-react";

const NAV_LINKS = [
  { label: "Home",           page: "home" },
  { label: "URL Scanner",    page: "scanner" },
  { label: "File Complaint", page: "complain" },
  { label: "Cyber Info",     page: "info" },
];

export default function Footer({ setPage }) {
  return (
    <footer className="bg-blue-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">

          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 bg-white/10 rounded-xl flex items-center justify-center">
                <Shield className="w-5 h-5 text-orange-400" />
              </div>
              <div>
                <div className="font-bold text-white">CyberSuraksha</div>
                <div className="text-xs text-orange-400">Digital India Initiative</div>
              </div>
            </div>
            <p className="text-blue-200 text-sm leading-relaxed">
              Protecting Indian citizens in the digital age. Report cyber crimes, stay informed, and browse safely.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-orange-400 mb-3 text-sm uppercase tracking-wider">Quick Links</h4>
            <div className="space-y-2">
              {NAV_LINKS.map(({ label, page }) => (
                <button
                  key={page}
                  onClick={() => setPage(page)}
                  className="block text-blue-200 hover:text-white text-sm transition-colors"
                >
                  → {label}
                </button>
              ))}
            </div>
          </div>

          {/* Emergency Contacts */}
          <div>
            <h4 className="font-semibold text-orange-400 mb-3 text-sm uppercase tracking-wider">Emergency Contacts</h4>
            <div className="space-y-2 text-sm text-blue-200">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-orange-400" />
                <span>Cyber Helpline: <strong className="text-white">1930</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-orange-400" />
                <span>cybercrime.gov.in</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-400" />
                <span>help@cybercrime.gov.in</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-blue-800 mt-8 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-blue-300 text-xs">
            © 2025 CyberSuraksha · Ministry of Home Affairs, Government of India
          </p>
          {/* Tricolour accent */}
          <div className="flex items-center gap-1">
            <div className="w-5 h-3 bg-orange-500 rounded-sm" />
            <div className="w-5 h-3 bg-white rounded-sm" />
            <div className="w-5 h-3 bg-green-600 rounded-sm" />
          </div>
        </div>
      </div>
    </footer>
  );
}
