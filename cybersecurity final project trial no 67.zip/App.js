// ============================================================
// FILE: App.js
// Main application entry point with routing and global layout
// ============================================================

import { useState } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import HomePage from "./pages/Home";
import ScannerPage from "./pages/Scanner";
import ComplainPage from "./pages/Complain";
import InfoPage from "./pages/Info";

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");

  const renderPage = () => {
    switch (currentPage) {
      case "home":    return <HomePage setPage={setCurrentPage} />;
      case "scanner": return <ScannerPage />;
      case "complain":return <ComplainPage />;
      case "info":    return <InfoPage />;
      default:        return <HomePage setPage={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-white font-sans">
      <Navbar currentPage={currentPage} setPage={setCurrentPage} />
      <main>{renderPage()}</main>
      <Footer setPage={setCurrentPage} />
    </div>
  );
}
